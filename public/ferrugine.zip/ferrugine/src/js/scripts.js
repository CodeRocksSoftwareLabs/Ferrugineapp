$(document).ready(function() {
	var HeightHeader = $(".app-header-pages").height();
	var PaddingAppMain = HeightHeader + 45;

	//console.log(PaddingAppMain);

    $(".app-main").css({ "padding-top": +PaddingAppMain+"px" });


    // menu bar

    $( ".menu-bar__button" ).click(function() {
  		$( "html" ).toggleClass( "menu-open" );
	});
	$( ".menu-bar__close" ).click(function() {
		$( "html" ).toggleClass( "menu-open" );
	});

	$('#btn_login').on('click', function(e){
	   e.preventDefault();

	   var csenha = $('input[name=cpassword]').val();
	   var senha = $('input[name=password]').val();

	   if (senha !== csenha) {
	       $('.alert-danger').html('As senhas não conferem');
           $('.alert-danger').show();
           //$('.btn-block').attr('disabled', 'disabled');
           //$('.btn-block').css('backgroundColor', '#d2d2d2');
           return false;
       }
	   else{
           $('.alert-danger').hide();
           //$('.btn-block').removeAttr('disabled', 'disabled');
           //$('.btn-block').css('backgroundColor', '#e63429');

           $('#form_nova_senha').submit();
       }
    });

	$('input[name=email]').keyup(function(){
        var valor = $(this).val();
        if(valor.indexOf('@') === -1){
            $('input[name=username]').val(valor);
        }
    });

	$('select[name=mes]').on('change', function (e) {
        var mes = $(this).val();

        if (mes !== '') {
            mes = parseInt(mes);
            $('.dias').each(function (key, value) {
                if ($(this).data('mes') !== mes) {
                    $(this).hide();
                } else {
                    $(this).show();
                }
            });
        } else {
            $('.dias').show();
        }
    });

    $('input[name=pesquisar]').keyup(function(){
        var q = $(this).val();

        if(q !== "") {
            q = q.toLowerCase();
            $('.client-list__group').hide();
            $('.client-list__group').each(function (key, value) {
                $(this).children('.client-list__order').children('.client-list__item').each(function (key2, value2) {
                    var nome = value2.getAttribute('data-nome');
                    var telefone = value2.getAttribute('data-telefone');

                    if (nome.indexOf(q) !== -1) {
                        $(this).parent('.client-list__order').parent('.client-list__group').show();
                    }
                    else if(telefone.indexOf(q) !== -1) {
                        $(this).parent('.client-list__order').parent('.client-list__group').show();
                    }
                });
            });
        } else {
            $('.client-list__group').show();
        }
    });

});

jQuery(function() {

    //======================= Util ==============================//
    jQuery('.data').mask('99/99/9999');
    jQuery('.cpf').mask('999.999.999-999');
    jQuery('.cep').mask('99999-999');
    jQuery('.hora').mask('99:99');
    jQuery('.telefone').focusout(function(){
        var phone,element;
        element=$(this);
        element.unmask();
        phone=element.val().replace(/\D/g,'');

        if(phone.length>10){
            element.mask("(99) 99999-9999");
        }else{
            element.mask("(99) 9999-99999");
        }
    }).trigger('focusout');

    if($('#cliente_nome').length > 0)
    {
        $('#cliente_nome').typeahead({
            hint: false,
            highlight: true,
            minLength: 1
        },{
            name: 'cliente_nome',
            source: substringMatcher(clientes_nomes)
        });
    }

    $('#cliente_nome').focusout(function(){
        var q = $(this).val();

        if (q != "") {
            $.ajax({
                url: '/clientes/async/' + q,
                type: 'GET',
                success: function (resposta) {
                    console.log(resposta);
                    $('#cliente_id').val(resposta.id);
                    var html = '<strong class="title-form-label">Selecionado:</strong><span class="card-client__name">'+resposta.ds_nome+'</span><span class="card-client__phone">'+resposta.ds_telefone+'</span>';
                    $('#cliente_target a').html(html);
                    $('#cliente_target').show();
                },
                error: function (resposta, status, error) {
                    $('#cliente_id').val("");
                    $('#cliente_target').hide();

                    Swal.fire({
                        type: status,
                        text: resposta.responseJSON.message,
                    });

                    $(this).val("");
                    $(this).focus();
                }
            });
        } else {
            $(this).val("");
            $(this).focus();
        }
    });
});

var substringMatcher = function(strs) {
    return function findMatches(q, cb) {
        var matches, substringRegex;

        matches = [];

        substrRegex = new RegExp(q, 'i');

        $.each(strs, function(i, str) {
            if (substrRegex.test(str)) {
                matches.push(str);
            }
        });

        cb(matches);
    };
};


