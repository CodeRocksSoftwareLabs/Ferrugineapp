$(function(){
    $('.excluir').on('click', function(e){
        e.preventDefault();
        var href = $(this).attr('href');

        Swal.fire({
            title: 'Você tem certeza?',
            text: "Não será possível desfazer esta ação.",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e63429',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Excluir',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {
                window.location.href = href;
            }
        });
    });
});
